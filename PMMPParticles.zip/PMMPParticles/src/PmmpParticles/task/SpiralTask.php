<?php

namespace PmmpParticles\task;

use pocketmine\math\Vector3;
use pocketmine\Player;
use PmmpParticles\PmmpParticles;
use PmmpParticles\base\BaseTask;

class SpiralTask extends BaseTask
{

    public function onRun($tick)
    {
        $t = $this->getPlugin()->getData()->getAll();
        $ej = $this->plugin->data->getAll();
        foreach (array_keys($ej) as $name){
            $x = $ej[$name]["pos"]["x"];
            $y = $ej[$name]["pos"]["y"];
            $z = $ej[$name]["pos"]["z"];
            $level = $this->getPlugin()->getServer()->getLevelByName($ej[$name]["pos"]["world"]);
            for($i=0;$i<$ej[$name]["amplifier"];$i++){
                foreach($ej[$name]["particle"] as $parti){
                    $level->addParticle($this->getPlugin()->getParticles()->getTheParticle($parti, new Vector3($x, $y, $z)));
                }
            }
        }
    }
}

?>
