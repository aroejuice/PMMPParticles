<?php

namespace pmmpparticles\base;

use pocketmine\scheduler\Task;
use pmmpparticles\pmmpparticles;

abstract class BaseTask extends Task{

	protected $plugin;

    public function __construct(pmmpparticles $plugin){
        $this->plugin = $plugin;
    }

    public final function getPlugin(){
        return $this->plugin;
    }

    public final function getConfig(){
        return $this->plugin->getConfig();
    }

}
