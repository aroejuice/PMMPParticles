<?php

namespace PmmpParticles\base;

use pocketmine\command\PluginCommand;
use pocketmine\plugin\Plugin;
use pocketmine\command\CommandExecutor;
use PmmpParticles\PmmpParticles;

abstract class BaseCommand extends PluginCommand implements CommandExecutor{

	protected $plugin;

	public function __construct (aloeparticles $plugin){
		$this->plugin = $plugin;
	}

    public final function getPlugin(): Plugin{
        return $this->plugin;
    }

	public final function getConfig(){
		return $this->plugin->getConfig();
	}
}
