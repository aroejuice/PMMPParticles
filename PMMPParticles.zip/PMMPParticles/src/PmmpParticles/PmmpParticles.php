<?php

namespace PmmpParticles;

use pocketmine\plugin\PluginDescription;
use pocketmine\plugin\PluginLoader;
use pocketmine\Server;
use PmmpParticles\task\SpiralTask;
use PmmpParticles\commands\PmmpParticlesCommand;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\level\Position;

class PmmpParticles extends PluginBase
{

    public function __construct(PluginLoader $loader, Server $server, PluginDescription $description, string $dataFolder, $file)
    {
        parent::__construct($loader, $server, $description, $dataFolder, $file);
    }

    public $data;

    private static $instance = null;

    private $provider = "YAML";

    public static function getInstance(): PmmpParticles
    {
        return self::$instance;
    }

    public function onEnable()
    {
        $this->getLogger()->info("pmmpparticlesをロード中です(´･ω･`)");
        if (!is_dir($this->getDataFolder())) {
            mkdir($this->getDataFolder());
        }
        $this->data = new Config($this->getDataFolder() . "ejector.yml", Config::YAML, array());
        self::$instance = $this;
        $this->particles = new Particles ($this);
        $this->getScheduler()->scheduleRepeatingTask(new SpiralTask ($this), 3);
        $this->getCommand("pmmpparticles")->setExecutor(new PmmpParticlesCommand($this));
        $this->getLogger()->info("読み込みに成功しました");
    }

    public function getData($file = "data")
    {
        return $this->data;
    }

    public function getParticles()
    {
        $particles = new Particles ($this);
        return $particles;
    }

    public function setEjector($name, Position $pos, array $particles, $amplifier = 1, $type = "normal")
    {
        $ed = $this->data->getAll();
        if (array_key_exists($name, $ed) !== false) {
            unset($ed[$name]);
        }
        $ed[$name]["pos"]["x"] = $pos->x;
        $ed[$name]["pos"]["y"] = $pos->y + 1;
        $ed[$name]["pos"]["z"] = $pos->z;
        $ed[$name]["pos"]["world"] = $pos->getLevel()->getName();
        foreach ($particles as $particle) {
            $ed[$name]["particle"][] = $particle;
        }
        $ed[$name]["amplifier"] = $amplifier;
        $this->data->setAll($ed);
        $this->data->save();
        return true;
    }

    public function isEjectorExists($name)
    {
        $ed = $this->data->getAll();
        return (bool)array_key_exists($name, $ed);
    }

    public function removeEjector($name)
    {
        $ed = $this->data->getAll();
        if (array_key_exists($name, $ed)) {
            unset($ed[$name]);
            $this->data->setAll($ed);
            $this->data->save();
            return true;
        }
        return false;
    }

    public function getAllEjectors()
    {
        $ed = $this->data->getAll();
        return implode(", ", array_keys($ed));
    }
}

?>
